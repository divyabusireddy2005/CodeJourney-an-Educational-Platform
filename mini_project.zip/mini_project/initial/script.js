document.addEventListener("DOMContentLoaded", function () {
    const signInBtn = document.getElementById("sign-in-btn");
    const modal = document.getElementById("sign-in-modal");
    const closeModal = document.querySelector(".close");
    const submitBtn = document.getElementById("submit-btn");
    const usernameInput = document.getElementById("username");
    const authContainer = document.getElementById("auth-container");

    signInBtn.addEventListener("click", () => {
        modal.style.display = "flex";
    });

    closeModal.addEventListener("click", () => {
        modal.style.display = "none";
    });

    submitBtn.addEventListener("click", () => {
        const username = usernameInput.value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
    
        if (username && email && password) {
            const initial = username.charAt(0).toUpperCase();
            authContainer.innerHTML = `<div class='user-icon'>${initial}</div>`;
            modal.style.display = "none";
        }
    });
    

    window.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.style.display = "none";
        }
    });
});


