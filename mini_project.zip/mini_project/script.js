document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM fully loaded and parsed");

    // Cache DOM elements
    const signInModal = document.getElementById("sign-in-modal");
    const signUpModal = document.getElementById("sign-up-modal");
    const signInBtn = document.getElementById("signInBtn");
    const signUpBtn = document.getElementById("signUpBtn");
    const logoutBtn = document.getElementById("logoutBtn");
    const closeBtns = document.querySelectorAll(".close");
    const submitBtn = document.getElementById("submit-btn");
    const signUpSubmitBtn = document.getElementById("signup-submit-btn");
    const sidebarSearch = document.getElementById("sidebarSearch");
    const backToTopBtn = document.getElementById("back-to-top");

    // Check for missing critical elements
    if (!signInModal || !signUpModal || !signInBtn || !signUpBtn || !logoutBtn || !submitBtn || !signUpSubmitBtn) {
        console.error("One or more critical elements are missing.");
        return;
    }

    // Navbar toggle
    const menuIcon = document.getElementById("menu-icon");
    const navMenu = document.querySelector("nav ul");
    if (menuIcon && navMenu) {
        menuIcon.addEventListener("click", () => {
            navMenu.classList.toggle("active");
        });
    } else {
        console.error("Menu icon or nav menu not found.");
    }

    // User authentication logic
    const savedUser = localStorage.getItem("signedInUser");

    function updateUIForUser(user) {
        if (user) {
            signInBtn.textContent = user;
            logoutBtn.style.display = "inline-block";
            signInBtn.classList.remove("active-btn");
            signUpBtn.style.display = "none"; // Hide Sign Up button when signed in
        } else {
            signInBtn.textContent = "Sign In";
            logoutBtn.style.display = "none";
            signInBtn.classList.add("active-btn");
            signUpBtn.style.display = "inline-block"; // Show Sign Up button when not signed in
        }
        // Ensure navbar items stay in line (CSS fix needed in your stylesheet)
        // Example CSS: nav ul { display: flex; align-items: center; }
    }

    updateUIForUser(savedUser);

    // Modal interactions
    function openModal(modal) {
        console.log("Opening modal");
        modal.style.display = "flex";
        modal.setAttribute("aria-hidden", "false");
    }

    function closeModal(modal) {
        console.log("Closing modal");
        modal.style.display = "none";
        modal.setAttribute("aria-hidden", "true");
    }

    signInBtn.addEventListener("click", function (event) {
        event.preventDefault();
        console.log("Sign-In button clicked");
        openModal(signInModal);
    });

    signUpBtn.addEventListener("click", function (event) {
        event.preventDefault();
        console.log("Sign-Up button clicked");
        openModal(signUpModal);
    });

    closeBtns.forEach(btn => {
        btn.addEventListener("click", function () {
            console.log("Close button clicked");
            closeModal(signInModal);
            closeModal(signUpModal);
        });
    });

    window.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            if (signInModal.style.display === "flex") closeModal(signInModal);
            if (signUpModal.style.display === "flex") closeModal(signUpModal);
        }
    });

    window.addEventListener("click", function (event) {
        if (event.target === signInModal) closeModal(signInModal);
        if (event.target === signUpModal) closeModal(signUpModal);
    });

    // User Sign-In
    submitBtn.addEventListener("click", function () {
        const email = document.getElementById("email");
        const password = document.getElementById("password");
        const emailValue = email.value.trim();
        const passwordValue = password.value.trim();

        if (emailValue && passwordValue) {
            const userData = localStorage.getItem(emailValue);
            if (userData) {
                const user = JSON.parse(userData);
                if (user.password === passwordValue) {
                    localStorage.setItem("signedInUser", user.username);
                    updateUIForUser(user.username);
                    closeModal(signInModal);
                    alert("Sign In Successful!");
                    // Clear input fields after successful sign-in
                    email.value = "";
                    password.value = "";
                } else {
                    alert("Incorrect password!");
                }
            } else {
                alert("User not found. Please Sign Up.");
            }
        } else {
            alert("Please fill all fields!");
        }
    });

    // User Sign-Up
    signUpSubmitBtn.addEventListener("click", function () {
        const username = document.getElementById("signup-username");
        const email = document.getElementById("signup-email");
        const password = document.getElementById("signup-password");
        const usernameValue = username.value.trim();
        const emailValue = email.value.trim();
        const passwordValue = password.value.trim();

        if (usernameValue && emailValue && passwordValue) {
            const user = { username: usernameValue, email: emailValue, password: passwordValue };
            localStorage.setItem(emailValue, JSON.stringify(user));
            alert("Sign Up Successful! Please Sign In.");
            closeModal(signUpModal);
            // Clear input fields after successful sign-up
            username.value = "";
            email.value = "";
            password.value = "";
        } else {
            alert("Please fill all fields!");
        }
    });

    // User Logout
    logoutBtn.addEventListener("click", function (event) {
        event.preventDefault();
        localStorage.removeItem("signedInUser");
        updateUIForUser(null);
        alert("You have logged out successfully!");
    });

    // Back to Top Button
    if (backToTopBtn) {
        window.onscroll = function () {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                backToTopBtn.style.display = "block";
            } else {
                backToTopBtn.style.display = "none";
            }
        };

        backToTopBtn.addEventListener("click", function () {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        });
    }

    // Copy Code Function
    window.copyCode = function (button) {
        const code = button.nextElementSibling.querySelector("code").textContent;
        navigator.clipboard.writeText(code).then(() => {
            button.textContent = "Copied!";
            setTimeout(() => (button.textContent = "Copy"), 2000);
        });
    };

    // Feedback Function
    window.submitFeedback = function () {
        const feedback = document.getElementById("feedback").value.trim();
        if (feedback) {
            document.getElementById("feedbackMessage").textContent = "Thank you for your feedback!";
            document.getElementById("feedback").value = "";
        } else {
            document.getElementById("feedbackMessage").textContent = "Please enter some feedback!";
        }
    };

    // Dark Mode Toggle
    window.toggleTheme = function () {
        document.body.classList.toggle("dark-mode");
        localStorage.setItem("theme", document.body.classList.contains("dark-mode") ? "dark" : "light");
    };
    if (localStorage.getItem("theme") === "dark") {
        document.body.classList.add("dark-mode");
    }

    // Sidebar Search Function
    window.filterTopics = function () {
        const input = document.getElementById("sidebarSearch").value.toLowerCase();
        const topics = document.querySelectorAll(".sidebar-list li");
        topics.forEach(topic => {
            const text = topic.textContent.toLowerCase();
            topic.style.display = text.includes(input) ? "block" : "none";
        });
    };

    // Clear sidebar search input on load
    if (sidebarSearch) {
        sidebarSearch.value = "";
    }

    // Commented out Enter key functionality for sign-in and sign-up
    /*
    // Sign-In with Enter key on password field
    document.getElementById("password").addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            const email = document.getElementById("email");
            const password = document.getElementById("password");
            const emailValue = email.value.trim();
            const passwordValue = password.value.trim();

            if (emailValue && passwordValue) {
                const userData = localStorage.getItem(emailValue);
                if (userData) {
                    const user = JSON.parse(userData);
                    if (user.password === passwordValue) {
                        localStorage.setItem("signedInUser", user.username);
                        updateUIForUser(user.username);
                        closeModal(signInModal);
                        alert("Sign In Successful!");
                        email.value = "";
                        password.value = "";
                    } else {
                        alert("Incorrect password!");
                    }
                } else {
                    alert("User not found. Please Sign Up.");
                }
            } else {
                alert("Please fill all fields!");
            }
        }
    });

    // Sign-Up with Enter key on password field
    document.getElementById("signup-password").addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            const username = document.getElementById("signup-username");
            const email = document.getElementById("signup-email");
            const password = document.getElementById("signup-password");
            const usernameValue = username.value.trim();
            const emailValue = email.value.trim();
            const passwordValue = password.value.trim();

            if (usernameValue && emailValue && passwordValue) {
                const user = { username: usernameValue, email: emailValue, password: passwordValue };
                localStorage.setItem(emailValue, JSON.stringify(user));
                alert("Sign Up Successful! Please Sign In.");
                closeModal(signUpModal);
                username.value = "";
                email.value = "";
                password.value = "";
            } else {
                alert("Please fill all fields!");
            }
        }
    });
    */
});

// Define searchLanguage in the global scope (if used in index.html)
function searchLanguage() {
    const searchInput = document.getElementById("searchInput");
    if (!searchInput) return;
    const query = searchInput.value.trim().toLowerCase();
    const languages = {
        python: "python.html",
        java: "java.html",
        javascript: "js.html",
        html: "html.html",
        css: "css.html",
        c: "c.html"
    };

    const matchedLanguage = Object.keys(languages).find(lang => lang.includes(query));
    if (matchedLanguage) {
        window.location.href = languages[matchedLanguage];
    } else {
        alert("Language not found!");
    }
    searchInput.value = "";
}